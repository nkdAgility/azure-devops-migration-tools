---
redirectFrom: []
layout: page
toc: true
title: Work items are not migrated!
categories:
  - Work Items
---

Maybe you see a `TF237124: Work Item is not ready to save` error when you attempt to do a migration.

Posible solutions are:

- [Work items are not migrated!](work-items-are-not-migrated.md)
