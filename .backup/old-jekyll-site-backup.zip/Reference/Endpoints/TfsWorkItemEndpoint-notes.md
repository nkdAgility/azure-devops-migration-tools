The Work Item endpoint is super awesome.

|Client  | WriteTo/ReadFrom | Endpoint | Data Target | Description |
|:-:|:-:|:-:|:-:|:-:|
AzureDevops.ObjectModel | Tfs Object Model | `TfsWorkItemEndPoint` | WorkItems | TBA
AzureDevops.Rest | Azure DevOps REST | ?
FileSystem | Local Files | `FileSystemWorkItemEndpoint` | WorkItems | TBA

