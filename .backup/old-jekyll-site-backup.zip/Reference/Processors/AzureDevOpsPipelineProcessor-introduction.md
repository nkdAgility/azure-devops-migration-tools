
## Features
- Migrates service connections
- Migrates variable groups
- Migrates task groups
- Migrates classic and yml build pipelines
- Migrates release pipelines