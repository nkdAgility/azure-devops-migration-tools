---
title: FieldMaps
layout: page
pageType: index
toc: true
pageStatus: published
discussionId:
---

These fieldMaps are provided to allow you to modify the data as you do the migration.

{% include content-collection-table.html collection = "reference" typeName = "FieldMaps" architecture = "v1" %}
