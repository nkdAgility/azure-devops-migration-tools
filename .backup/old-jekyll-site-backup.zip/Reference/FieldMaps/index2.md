---
title: Field Maps
layout: page
template: default
toc: true
pageStatus: published
discussionId: 
redirect_from: 
 - /Reference/v2/FieldMaps.html
---


>**_This documentation is for a preview version of the Azure DevOps Migration Tools._ If you are not using the preview version then please head over to the main [documentation](https://nkdagility.com/docs/azure-devops-migration-tools).**

<Description>

### Options

<Options>

### Example JSON

```JSON
<ExampleJson>
```